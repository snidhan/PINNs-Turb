This directoy    contains the spectra   for experiment 2 (u, single wire)   
                                            u (exp 3)  
                                            v (exp 3)   X-wires
                                            w (exp 4)

Files names are of the form      s????mlB.CCC, where:   
        ????: 0200 or  0800 (X location in mm.)
           B: 2  u  v  w   
         CCC: probe y-position index (actual y in mm is given inside the files)

