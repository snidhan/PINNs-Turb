same rule as for spectra   applied here for PDF see ../spectra/README
