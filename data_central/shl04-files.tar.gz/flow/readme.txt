delom.ml1	evolution of delta_omega
gen.dat		useful quantities
thephis.ml1	coordinates of iso velocity points in x-y plane see ../figures/rawdata/xtthephi.gp
theta.ml1	evolution of theta
uaub.ml1	evolution of Ua and Ub


All this from experiment I
