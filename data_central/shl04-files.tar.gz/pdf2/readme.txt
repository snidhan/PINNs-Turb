References about this mixing layer:
J. DELVILLE "La decomposition orthogonale aux valeurs
 propres et l'analyse de l'organisation
 tridimensionnelle des ecoulements turbulents cisailles
 libres". These, Universite de Poitiers, Janv. 1995.
J. DELVILLE, S. BELLIN, J.-H. GAREM & J.-P. BONNET
 "Analysis of structures in a turbulent plane mixing
 layer by use of a pseudo-flow visualization method
 based hot-wire anemometry". 1988, in Advances in
 Turbulence II, Fernholz and Fiedler eds., Springer,
 pp. 251.


-------------------------------------------------------------------------------

Probability Density Functions: TWO Point or Space
correlations

-------------------------------------------------------------------------------

Special file organization:
  _Four first lines of comment begining by "#" and then:
     _First column: velocity/sigma
     _Second column: y (constant)
     _Third column: sigma P(velocity/sigma)
  _One line of comment begining by "#"

_ pdf of u, x=800mm, y=-35.06mm                                 :     file C01
_ pdf of u, x=800mm, y=-29.46mm                                 :     file C02
_ pdf of u, x=800mm, y=-23.86mm                                 :     file C03
_ pdf of u, x=800mm, y=-18.26mm                                 :     file C04
_ pdf of u, x=800mm, y=-12.66mm                                 :     file C05
_ pdf of u, x=800mm, y=-7.06mm                                  :     file C06
_ pdf of u, x=800mm, y=-1.46mm                                  :     file C07
_ pdf of u, x=800mm, y=4.14mm                                   :     file C08
_ pdf of u, x=800mm, y=9.74mm                                   :     file C09
_ pdf of u, x=800mm, y=15.34mm                                  :     file C10
_ pdf of u, x=800mm, y=20.94mm                                  :     file C11
_ pdf of u, x=800mm, y=26.54mm                                  :     file C12
_ pdf of u, x=800mm, y=32.14mm                                  :     file C13
_ pdf of u, x=800mm, y=37.74mm                                  :     file C14
_ pdf of u, x=800mm, y=43.34mm                                  :     file C15
_ pdf of u, x=800mm, y=48.94mm                                  :     file C16

_ pdf of v, x=800mm, y=-35.06mm                                 :     file C17
_ pdf of v, x=800mm, y=-29.46mm                                 :     file C18
_ pdf of v, x=800mm, y=-23.86mm                                 :     file C19
_ pdf of v, x=800mm, y=-18.26mm                                 :     file C20
_ pdf of v, x=800mm, y=-12.66mm                                 :     file C21
_ pdf of v, x=800mm, y=-7.06mm                                  :     file C22
_ pdf of v, x=800mm, y=-1.46mm                                  :     file C23
_ pdf of v, x=800mm, y=4.14mm                                   :     file C24
_ pdf of v, x=800mm, y=9.74mm                                   :     file C25
_ pdf of v, x=800mm, y=15.34mm                                  :     file C26
_ pdf of v, x=800mm, y=20.94mm                                  :     file C27
_ pdf of v, x=800mm, y=26.54mm                                  :     file C28
_ pdf of v, x=800mm, y=32.14mm                                  :     file C29
_ pdf of v, x=800mm, y=37.74mm                                  :     file C30
_ pdf of v, x=800mm, y=43.34mm                                  :     file C31
_ pdf of v, x=800mm, y=48.94mm                                  :     file C32

_ pdf of w, x=800mm, y=-35.06mm                                 :     file C33
_ pdf of w, x=800mm, y=-29.46mm                                 :     file C34
_ pdf of w, x=800mm, y=-23.86mm                                 :     file C35
_ pdf of w, x=800mm, y=-18.26mm                                 :     file C36
_ pdf of w, x=800mm, y=-12.66mm                                 :     file C37
_ pdf of w, x=800mm, y=-7.06mm                                  :     file C38
_ pdf of w, x=800mm, y=-1.46mm                                  :     file C39
_ pdf of w, x=800mm, y=4.14mm                                   :     file C40
_ pdf of w, x=800mm, y=9.74mm                                   :     file C41
_ pdf of w, x=800mm, y=15.34mm                                  :     file C42
_ pdf of w, x=800mm, y=20.94mm                                  :     file C43
_ pdf of w, x=800mm, y=26.54mm                                  :     file C44
_ pdf of w, x=800mm, y=32.14mm                                  :     file C45
_ pdf of w, x=800mm, y=37.74mm                                  :     file C46
_ pdf of w, x=800mm, y=43.34mm                                  :     file C47
_ pdf of w, x=800mm, y=48.94mm                                  :     file C48

-----------------------------------------------------------------------------

Joint Probability Density Functions:
File organization : 2 columns

_ jpdf of u2-u1 x=600mm, y1=3mm, y2=9mm                         :     file C49
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=15mm                        :     file C50
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=21mm                        :     file C51
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=27mm                        :     file C52
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=33mm                        :     file C53

_ jpdf of v2-v1 x=600mm, y1=3mm, y2=9mm                         :     file C54
_ jpdf of v2-v1 x=600mm, y1=3mm, y2=15mm                        :     file C55
_ jpdf of v2-v1 x=600mm, y1=3mm, y2=21mm                        :     file C56
_ jpdf of v2-v1 x=600mm, y1=3mm, y2=27mm                        :     file C57
_ jpdf of v2-v1 x=600mm, y1=3mm, y2=33mm                        :     file C58

_ jpdf of u2-u1 x=600mm, y1=15mm, y2=-21mm                      :     file C59
_ jpdf of u2-u1 x=600mm, y1=15mm, y2=-15mm                      :     file C60
_ jpdf of u2-u1 x=600mm, y1=15mm, y2=-9mm                       :     file C61
_ jpdf of u2-u1 x=600mm, y1=15mm, y2=-3mm                       :     file C62
_ jpdf of u2-u1 x=600mm, y1=15mm, y2=3mm                        :     file C63
_ jpdf of u2-u1 x=600mm, y1=15mm, y2=15mm                       :     file C64
_ jpdf of u2-u1 x=600mm, y1=15mm, y2=21mm                       :     file C65
_ jpdf of u2-u1 x=600mm, y1=15mm, y2=27mm                       :     file C66
_ jpdf of u2-u1 x=600mm, y1=15mm, y2=33mm                       :     file C67

_ jpdf of v2-v1 x=600mm, y1=15mm, y2=-21mm                      :     file C68
_ jpdf of v2-v1 x=600mm, y1=15mm, y2=-15mm                      :     file C69
_ jpdf of v2-v1 x=600mm, y1=15mm, y2=-9mm                       :     file C70
_ jpdf of v2-v1 x=600mm, y1=15mm, y2=-3mm                       :     file C71
_ jpdf of v2-v1 x=600mm, y1=15mm, y2=3mm                        :     file C72
_ jpdf of v2-v1 x=600mm, y1=15mm, y2=15mm                       :     file C73
_ jpdf of v2-v1 x=600mm, y1=15mm, y2=21mm                       :     file C74
_ jpdf of v2-v1 x=600mm, y1=15mm, y2=27mm                       :     file C75
_ jpdf of v2-v1 x=600mm, y1=15mm, y2=33mm                       :     file C76

_ jpdf of u2-u1 x=600mm, y1=27mm, y2=-33mm                      :     file C77
_ jpdf of u2-u1 x=600mm, y1=27mm, y2=-21mm                      :     file C78
_ jpdf of u2-u1 x=600mm, y1=27mm, y2=-9mm                       :     file C79
_ jpdf of u2-u1 x=600mm, y1=27mm, y2=3mm                        :     file C80
_ jpdf of u2-u1 x=600mm, y1=27mm, y2=15mm                       :     file C81

_ jpdf of v2-v1 x=600mm, y1=27mm, y2=-33mm                      :     file C82
_ jpdf of v2-v1 x=600mm, y1=27mm, y2=-21mm                      :     file C83
_ jpdf of v2-v1 x=600mm, y1=27mm, y2=-9mm                       :     file C84
_ jpdf of v2-v1 x=600mm, y1=27mm, y2=3mm                        :     file C85
_ jpdf of v2-v1 x=600mm, y1=27mm, y2=15mm                       :     file C86

_ jpdf of u2-u1 x=600mm, y1=3mm, y2=9mm, t2-t1=-0.2ms           :     file C87
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=9mm, t2-t1=-0.5ms           :     file C88
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=9mm, t2-t1=-0.9ms           :     file C89
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=15mm, t2-t1=-0.2ms          :     file C90
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=15mm, t2-t1=-0.5ms          :     file C91
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=15mm, t2-t1=-0.9ms          :     file C92
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=21mm, t2-t1=-0.2ms          :     file C93
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=21mm, t2-t1=-0.5ms          :     file C94
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=21mm, t2-t1=-0.9ms          :     file C95
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=27mm, t2-t1=-0.2ms          :     file C96
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=27mm, t2-t1=-0.5ms          :     file C97
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=27mm, t2-t1=-0.9ms          :     file C98
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=33mm, t2-t1=-0.2ms          :     file C99
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=33mm, t2-t1=-0.5ms          :     file C100
_ jpdf of u2-u1 x=600mm, y1=3mm, y2=33mm, t2-t1=-0.9ms          :     file C101





